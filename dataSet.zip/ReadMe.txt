README:

Las siguientes carpetas y archivos tienen el siguiente esquema de nombramiento

Las carpetas se dividen en 2 categorías:

	- Transferencia Original
	- Transferencia Modificada

La "Transferencia Original" significa que se utilizó la función de transferencia original G_2(s) y la "Transferencia Modificada" significa que realizaron los cálculos con la variante de la función de transferencia G_2(s) pero quitándole el cero centrado en 1.53.

En ambas categorías, algunas vienen acompañadas de un R0_5 o R1_5 donde estos significan que la matriz de penalización R es igual a 0.5 o 1.5 para todos los archivos que están contenidos dentro de esta.

Dentro de los archivos internos de cada carpeta, siguen otro esquema de nombramiento que va de la siguiente manera.

Los archivos pueden tener inicialmente el nombre "Rlocus" o el nombre "Step", lo que significan que son un lugar de las raíces y una respuesta al escalón respectivamente. Los números que vienen después de cada nombre; son números separados con guiones y vienen en el siguiente formato:

nombre-parámetroA1MatrizQ-parámetroA2MatrizQ-parámetroMatrizR



